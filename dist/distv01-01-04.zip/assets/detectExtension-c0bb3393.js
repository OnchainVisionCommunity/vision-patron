import{cb as r}from"./index-3b8711e5.js";function o(e){const t=Array.isArray(e.method)?e.method[0]:r(e.method);return e.availableSelectors.includes(t)}export{o as d};
