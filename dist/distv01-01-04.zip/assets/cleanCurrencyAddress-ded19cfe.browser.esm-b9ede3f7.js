import{j as a,ah as e}from"./index-3b8711e5.js";function t(r){return a(r)?e:r}export{t as c};
