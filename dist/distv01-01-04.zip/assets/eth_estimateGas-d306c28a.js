import{c3 as s}from"./index-3b8711e5.js";async function m(t,e){const a=await t({method:"eth_estimateGas",params:[e]});return s(a)}export{m as eth_estimateGas};
