class a{constructor(r){this.contractWrapper=r}overrideNextTransaction(r){this.contractWrapper.withTransactionOverride(r)}}export{a as C};
